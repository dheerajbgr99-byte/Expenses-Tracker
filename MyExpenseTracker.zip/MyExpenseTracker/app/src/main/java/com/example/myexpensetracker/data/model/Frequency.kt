package com.example.myexpensetracker.data.model

enum class Frequency(val displayName: String) {
    MONTHLY("Monthly"),
    WEEKLY("Weekly"),
    YEARLY("Yearly")
}
