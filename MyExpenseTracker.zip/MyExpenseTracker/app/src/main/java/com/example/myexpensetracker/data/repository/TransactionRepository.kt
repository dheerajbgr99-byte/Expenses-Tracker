package com.example.myexpensetracker.data.repository

import com.example.myexpensetracker.data.local.dao.BudgetDao
import com.example.myexpensetracker.data.local.dao.EmiDao
import com.example.myexpensetracker.data.local.dao.FixedExpenseDao
import com.example.myexpensetracker.data.local.dao.TransactionDao
import com.example.myexpensetracker.data.local.entity.BudgetEntity
import com.example.myexpensetracker.data.local.entity.EmiEntity
import com.example.myexpensetracker.data.local.entity.FixedExpenseEntity
import com.example.myexpensetracker.data.local.entity.TransactionEntity
import com.example.myexpensetracker.data.model.TransactionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class TransactionRepository(
    private val transactionDao: TransactionDao,
    private val budgetDao: BudgetDao,
    private val fixedExpenseDao: FixedExpenseDao,
    private val emiDao: EmiDao
) {
    // Transactions
    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()

    fun getRecentTransactions(limit: Int = 5): Flow<List<TransactionEntity>> =
        transactionDao.getRecentTransactions(limit)

    fun getTotalByType(type: TransactionType): Flow<Double?> =
        transactionDao.getTotalByType(type)

    fun getTotalByTypeBetween(type: TransactionType, startDate: Long, endDate: Long): Flow<Double?> =
        transactionDao.getTotalByTypeBetween(type, startDate, endDate)

    fun getTransactionsBetween(startDate: Long, endDate: Long): Flow<List<TransactionEntity>> =
        transactionDao.getTransactionsBetween(startDate, endDate)

    fun getFilteredTransactions(
        type: TransactionType?,
        category: String?,
        startDate: Long?,
        endDate: Long?,
        query: String?
    ): Flow<List<TransactionEntity>> = transactionDao.getFilteredTransactions(
        type, category, startDate, endDate, query
    )

    suspend fun getTransactionById(id: Long): TransactionEntity? = withContext(Dispatchers.IO) {
        transactionDao.getTransactionById(id)
    }

    suspend fun insertTransaction(transaction: TransactionEntity): Long = withContext(Dispatchers.IO) {
        transactionDao.insertTransaction(transaction)
    }

    suspend fun updateTransaction(transaction: TransactionEntity) = withContext(Dispatchers.IO) {
        transactionDao.updateTransaction(transaction)
    }

    suspend fun deleteTransaction(transaction: TransactionEntity) = withContext(Dispatchers.IO) {
        transactionDao.deleteTransaction(transaction)
    }

    // Budgets
    fun getBudgetForMonth(monthYear: String): Flow<BudgetEntity?> =
        budgetDao.getBudgetForMonth(monthYear)

    suspend fun setBudget(monthYear: String, amount: Double) = withContext(Dispatchers.IO) {
        budgetDao.setBudget(BudgetEntity(monthYear = monthYear, amount = amount))
    }

    // Fixed Expenses
    val allFixedExpenses: Flow<List<FixedExpenseEntity>> = fixedExpenseDao.getAllFixedExpenses()

    suspend fun insertFixedExpense(expense: FixedExpenseEntity) = withContext(Dispatchers.IO) {
        fixedExpenseDao.insertFixedExpense(expense)
    }

    suspend fun updateFixedExpense(expense: FixedExpenseEntity) = withContext(Dispatchers.IO) {
        fixedExpenseDao.updateFixedExpense(expense)
    }

    suspend fun deleteFixedExpense(expense: FixedExpenseEntity) = withContext(Dispatchers.IO) {
        fixedExpenseDao.deleteFixedExpense(expense)
    }

    // EMIs
    val allEmis: Flow<List<EmiEntity>> = emiDao.getAllEmis()

    suspend fun insertEmi(emi: EmiEntity) = withContext(Dispatchers.IO) {
        emiDao.insertEmi(emi)
    }

    suspend fun updateEmi(emi: EmiEntity) = withContext(Dispatchers.IO) {
        emiDao.updateEmi(emi)
    }

    suspend fun deleteEmi(emi: EmiEntity) = withContext(Dispatchers.IO) {
        emiDao.deleteEmi(emi)
    }

    // Backup & Wipe Helpers
    suspend fun getAllDataForBackup() = withContext(Dispatchers.IO) {
        // Collect snapshots for JSON serialization
        Triple(
            budgetDao.getAllBudgetsList(),
            fixedExpenseDao.getAllFixedExpensesList(),
            emiDao.getAllEmisList()
        )
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        transactionDao.clearAllTransactions()
        budgetDao.clearAllBudgets()
        fixedExpenseDao.clearAllFixedExpenses()
        emiDao.clearAllEmis()
    }
}
