package com.example.myexpensetracker.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.myexpensetracker.ExpenseTrackerApplication
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

class BillReminderWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? ExpenseTrackerApplication ?: return Result.failure()
        val prefs = app.userPreferencesRepository
        val enabled = prefs.notificationsEnabled.first()

        if (!enabled) {
            return Result.success()
        }

        val database = app.database
        val threeDaysInMillis = System.currentTimeMillis() + TimeUnit.DAYS.toMillis(3)

        // Check Fixed Expenses due soon
        val upcomingFixed = database.fixedExpenseDao().getUpcomingUnpaid(threeDaysInMillis)
        upcomingFixed.forEachIndexed { index, fixed ->
            NotificationHelper.showReminderNotification(
                applicationContext,
                1000 + index,
                "Upcoming Bill: ${fixed.title}",
                "Amount: ${fixed.amount} is due soon on ${java.text.SimpleDateFormat("dd MMM", java.util.Locale.getDefault()).format(java.util.Date(fixed.dueDate))}."
            )
        }

        // Check EMIs due soon
        val upcomingEmis = database.emiDao().getUpcomingDue(threeDaysInMillis)
        upcomingEmis.forEachIndexed { index, emi ->
            NotificationHelper.showReminderNotification(
                applicationContext,
                2000 + index,
                "Upcoming EMI: ${emi.loanName}",
                "Installment of ${emi.monthlyEmi} due to ${emi.lenderName} on ${java.text.SimpleDateFormat("dd MMM", java.util.Locale.getDefault()).format(java.util.Date(emi.nextDueDate))}."
            )
        }

        return Result.success()
    }
}
