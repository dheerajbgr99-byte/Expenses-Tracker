package com.example.myexpensetracker.ui.screens.dashboard

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.myexpensetracker.data.model.TransactionType
import com.example.myexpensetracker.ui.theme.ExpenseRedLight
import com.example.myexpensetracker.ui.theme.IncomeGreenLight
import com.example.myexpensetracker.ui.viewmodel.ExpenseViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: ExpenseViewModel,
    currencyCode: String = "INR",
    onNavigateToAdd: () -> Unit,
    onNavigateToTransactions: () -> Unit,
    onEditTransaction: (Long) -> Unit
) {
    val state by viewModel.dashboardUiState.collectAsState()
    var showBudgetDialog by remember { mutableStateOf(false) }
    var budgetInput by remember { mutableStateOf("") }

    val currencyFormatter = NumberFormat.getCurrencyInstance(
        if (currencyCode == "INR") Locale("en", "IN") else Locale.getDefault()
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Expense Tracker", fontWeight = FontWeight.Bold) }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToAdd,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Transaction")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Main Balance & Savings Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("Current Balance", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                        Text(
                            currencyFormatter.format(state.currentBalance),
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Savings, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Total Savings: ${currencyFormatter.format(state.totalSavings)}", fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }

            // Monthly Budget Card with 80% Warning and >100% Exceeded Alert
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            state.isBudgetExceeded -> MaterialTheme.colorScheme.errorContainer
                            state.isBudgetWarning -> MaterialTheme.colorScheme.tertiaryContainer
                            else -> MaterialTheme.colorScheme.surface
                        }
                    ),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Monthly Budget", fontWeight = FontWeight.Bold)
                            TextButton(onClick = {
                                budgetInput = state.currentMonthBudget?.toString() ?: ""
                                showBudgetDialog = true
                            }) {
                                Text(if (state.currentMonthBudget != null) "Edit Budget" else "Set Budget")
                            }
                        }

                        if (state.currentMonthBudget != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Spent: ${currencyFormatter.format(state.thisMonthExpenses)}")
                                Text("Budget: ${currencyFormatter.format(state.currentMonthBudget ?: 0.0)}")
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = (state.budgetUsedPercent / 100f).coerceIn(0f, 1f),
                                modifier = Modifier.fillMaxWidth().height(8.dp),
                                color = if (state.isBudgetExceeded) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "${state.budgetUsedPercent}% used · Remaining: ${currencyFormatter.format(state.budgetRemaining)}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )

                            // 80% Warning Banner
                            if (state.isBudgetWarning) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    "⚠️ Warning: You have reached 80% of your monthly budget!",
                                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Exceeded Alert Banner
                            if (state.isBudgetExceeded) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    "🚨 Alert: Budget exceeded by ${currencyFormatter.format(Math.abs(state.budgetRemaining))}!",
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        } else {
                            Text("No budget set for this month.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            // Income / Expense Summary Strip
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Income", style = MaterialTheme.typography.labelMedium)
                            Text(currencyFormatter.format(state.totalIncome), color = IncomeGreenLight, fontWeight = FontWeight.Bold)
                        }
                    }
                    Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Expenses", style = MaterialTheme.typography.labelMedium)
                            Text(currencyFormatter.format(state.totalExpenses), color = ExpenseRedLight, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Upcoming Fixed Expenses Widget
            if (state.upcomingFixedExpenses.isNotEmpty()) {
                item {
                    Text("Upcoming Fixed Expenses", fontWeight = FontWeight.Bold)
                    state.upcomingFixedExpenses.forEach { fixed ->
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(fixed.title, fontWeight = FontWeight.SemiBold)
                                    Text("Due soon · ${fixed.frequency.displayName}", style = MaterialTheme.typography.bodySmall)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(currencyFormatter.format(fixed.amount), fontWeight = FontWeight.Bold)
                                    IconButton(onClick = { viewModel.markFixedExpensePaid(fixed) }) {
                                        Icon(Icons.Default.Check, contentDescription = "Mark Paid")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Upcoming EMIs Widget
            if (state.upcomingEmis.isNotEmpty()) {
                item {
                    Text("Upcoming EMI Dues", fontWeight = FontWeight.Bold)
                    state.upcomingEmis.forEach { emi ->
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(emi.loanName, fontWeight = FontWeight.SemiBold)
                                    Text("${emi.lenderName} (${emi.paidInstallments}/${emi.totalInstallments})", style = MaterialTheme.typography.bodySmall)
                                }
                                Text(currencyFormatter.format(emi.monthlyEmi), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Recent Transactions Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Recent Transactions", fontWeight = FontWeight.Bold)
                    TextButton(onClick = onNavigateToTransactions) { Text("See All") }
                }
            }

            items(state.recentTransactions) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onEditTransaction(item.id) },
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(item.category, fontWeight = FontWeight.SemiBold)
                            Text("${item.paymentMethod.displayName}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text(
                            currencyFormatter.format(item.amount),
                            fontWeight = FontWeight.Bold,
                            color = if (item.type == TransactionType.INCOME) IncomeGreenLight else ExpenseRedLight
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(72.dp)) }
        }

        // Budget Setting Dialog
        if (showBudgetDialog) {
            AlertDialog(
                onDismissRequest = { showBudgetDialog = false },
                title = { Text("Set Monthly Budget") },
                text = {
                    OutlinedTextField(
                        value = budgetInput,
                        onValueChange = { budgetInput = it },
                        label = { Text("Budget Amount") },
                        singleLine = true
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val amt = budgetInput.toDoubleOrNull()
                        if (amt != null && amt > 0) {
                            viewModel.setMonthlyBudget(amt)
                        }
                        showBudgetDialog = false
                    }) {
                        Text("Save")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showBudgetDialog = false }) { Text("Cancel") }
                }
            )
        }
    }
}
