package com.example.myexpensetracker.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.myexpensetracker.data.local.dao.BudgetDao
import com.example.myexpensetracker.data.local.dao.EmiDao
import com.example.myexpensetracker.data.local.dao.FixedExpenseDao
import com.example.myexpensetracker.data.local.dao.TransactionDao
import com.example.myexpensetracker.data.local.entity.BudgetEntity
import com.example.myexpensetracker.data.local.entity.EmiEntity
import com.example.myexpensetracker.data.local.entity.FixedExpenseEntity
import com.example.myexpensetracker.data.local.entity.TransactionEntity

@Database(
    entities = [
        TransactionEntity::class,
        BudgetEntity::class,
        FixedExpenseEntity::class,
        EmiEntity::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class ExpenseDatabase : RoomDatabase() {

    abstract fun transactionDao(): TransactionDao
    abstract fun budgetDao(): BudgetDao
    abstract fun fixedExpenseDao(): FixedExpenseDao
    abstract fun emiDao(): EmiDao

    companion object {
        @Volatile
        private var INSTANCE: ExpenseDatabase? = null

        // Safe Room migration from v1 to v2 adding Budgets, Fixed Expenses, and EMI tables
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS budgets (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        monthYear TEXT NOT NULL,
                        amount REAL NOT NULL,
                        updatedAt INTEGER NOT NULL
                    )
                """)
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_budgets_monthYear ON budgets (monthYear)")

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS fixed_expenses (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        title TEXT NOT NULL,
                        amount REAL NOT NULL,
                        category TEXT NOT NULL,
                        dueDate INTEGER NOT NULL,
                        frequency TEXT NOT NULL,
                        isPaid INTEGER NOT NULL DEFAULT 0,
                        lastPaidDate INTEGER,
                        createdAt INTEGER NOT NULL
                    )
                """)

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS emi_records (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        loanName TEXT NOT NULL,
                        lenderName TEXT NOT NULL,
                        totalLoanAmount REAL NOT NULL,
                        monthlyEmi REAL NOT NULL,
                        interestRate REAL NOT NULL,
                        totalInstallments INTEGER NOT NULL,
                        paidInstallments INTEGER NOT NULL,
                        nextDueDate INTEGER NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                """)
            }
        }

        fun getDatabase(context: Context): ExpenseDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ExpenseDatabase::class.java,
                    "expense_tracker_database"
                )
                .addMigrations(MIGRATION_1_2)
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
