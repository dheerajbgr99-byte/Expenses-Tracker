package com.example.myexpensetracker.data.local.dao

import androidx.room.*
import com.example.myexpensetracker.data.local.entity.FixedExpenseEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FixedExpenseDao {
    @Query("SELECT * FROM fixed_expenses ORDER BY dueDate ASC")
    fun getAllFixedExpenses(): Flow<List<FixedExpenseEntity>>

    @Query("SELECT * FROM fixed_expenses")
    suspend fun getAllFixedExpensesList(): List<FixedExpenseEntity>

    @Query("SELECT * FROM fixed_expenses WHERE dueDate <= :thresholdDate AND isPaid = 0 ORDER BY dueDate ASC")
    suspend fun getUpcomingUnpaid(thresholdDate: Long): List<FixedExpenseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFixedExpense(expense: FixedExpenseEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(expenses: List<FixedExpenseEntity>)

    @Update
    suspend fun updateFixedExpense(expense: FixedExpenseEntity)

    @Delete
    suspend fun deleteFixedExpense(expense: FixedExpenseEntity)

    @Query("DELETE FROM fixed_expenses")
    suspend fun clearAllFixedExpenses()
}
