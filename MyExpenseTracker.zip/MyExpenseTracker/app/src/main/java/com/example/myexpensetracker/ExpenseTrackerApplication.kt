package com.example.myexpensetracker

import android.app.Application
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.myexpensetracker.data.local.ExpenseDatabase
import com.example.myexpensetracker.data.preferences.UserPreferencesRepository
import com.example.myexpensetracker.data.repository.TransactionRepository
import com.example.myexpensetracker.worker.BillReminderWorker
import com.example.myexpensetracker.worker.NotificationHelper
import java.util.concurrent.TimeUnit

class ExpenseTrackerApplication : Application() {

    val database: ExpenseDatabase by lazy { ExpenseDatabase.getDatabase(this) }
    
    val repository: TransactionRepository by lazy { 
        TransactionRepository(
            transactionDao = database.transactionDao(),
            budgetDao = database.budgetDao(),
            fixedExpenseDao = database.fixedExpenseDao(),
            emiDao = database.emiDao()
        ) 
    }

    val userPreferencesRepository: UserPreferencesRepository by lazy {
        UserPreferencesRepository(this)
    }

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createNotificationChannel(this)
        scheduleOfflineReminders()
    }

    private fun scheduleOfflineReminders() {
        val workRequest = PeriodicWorkRequestBuilder<BillReminderWorker>(
            repeatInterval = 1,
            repeatIntervalTimeUnit = TimeUnit.DAYS
        )
        .setConstraints(Constraints.Builder().build())
        .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "offline_bill_reminders",
            ExistingPeriodicWorkPolicy.KEEP,
            workRequest
        )
    }
}
