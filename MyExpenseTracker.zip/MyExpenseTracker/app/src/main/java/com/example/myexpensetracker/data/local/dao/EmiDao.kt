package com.example.myexpensetracker.data.local.dao

import androidx.room.*
import com.example.myexpensetracker.data.local.entity.EmiEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface EmiDao {
    @Query("SELECT * FROM emi_records ORDER BY nextDueDate ASC")
    fun getAllEmis(): Flow<List<EmiEntity>>

    @Query("SELECT * FROM emi_records")
    suspend fun getAllEmisList(): List<EmiEntity>

    @Query("SELECT * FROM emi_records WHERE nextDueDate <= :thresholdDate AND paidInstallments < totalInstallments ORDER BY nextDueDate ASC")
    suspend fun getUpcomingDue(thresholdDate: Long): List<EmiEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmi(emi: EmiEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(emis: List<EmiEntity>)

    @Update
    suspend fun updateEmi(emi: EmiEntity)

    @Delete
    suspend fun deleteEmi(emi: EmiEntity)

    @Query("DELETE FROM emi_records")
    suspend fun clearAllEmis()
}
