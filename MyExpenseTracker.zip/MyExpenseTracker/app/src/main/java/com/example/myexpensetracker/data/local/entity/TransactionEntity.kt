package com.example.myexpensetracker.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.myexpensetracker.data.model.PaymentMethod
import com.example.myexpensetracker.data.model.TransactionType

@Entity(
    tableName = "transactions",
    indices = [Index(value = ["date"]), Index(value = ["type"])]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val amount: Double,
    val type: TransactionType,
    val category: String,
    val paymentMethod: PaymentMethod,
    val date: Long, // Epoch timestamp in milliseconds
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
